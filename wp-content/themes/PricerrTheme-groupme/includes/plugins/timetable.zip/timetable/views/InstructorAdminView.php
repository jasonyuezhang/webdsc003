<?php
/**
 * @file
 * View template for the instructor admin view.
 *
 * @param array $data
 * 	Contains the data passed from the controller.
 */
?>

<h1><?php _e('Instructor Management', 'weekly-class-schedule'); ?></h1>